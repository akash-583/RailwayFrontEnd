import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomepageComponent } from './homepage/homepage.component';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { TrainListComponent } from './trainlist/trainlist.component';
import { IssueformComponent } from './issueform/issueform.component';
import { IssuelistComponent } from './issuelist/issuelist.component';
import { BookingformComponent } from './bookingform/bookingform.component';
import { PaymentComponent } from './payment/payment.component';
import { BookinglistComponent } from './bookinglist/bookinglist.component';
import { PaymentlistComponent } from './paymentlist/paymentlist.component';
import { UserlistComponent } from './userlist/userlist.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { ProfileComponent } from './profile/profile.component';
import { AddtrainComponent } from './addtrain/addtrain.component';
import { ThankyouComponent } from './thankyou/thankyou.component';
import { LogoutComponent } from './logout/logout.component';
import { CancelComponent } from './cancel/cancel.component';

const routes: Routes = [
  {path:'homepage',component:HomepageComponent},
  {path:'trainList',component:TrainListComponent},
  {path:'bookingform',component:BookingformComponent},
  {path:'adminlogin',component:AdminloginComponent},
  {path:'addtrain',component:AddtrainComponent},
  {path: 'paymentlist', component: PaymentlistComponent},
  {path: 'thankyou', component: ThankyouComponent},
  {path: 'logout', component: LogoutComponent},
  {path: 'profile', component: ProfileComponent},
  {path: 'cancel', component: CancelComponent},
  {path:'issueform',component:IssueformComponent},
  {path:'userlist',component:UserlistComponent},
  {path:'issuelist',component:IssuelistComponent},
  {path: 'payment', component: PaymentComponent},
  {path: 'bookinglist', component: BookinglistComponent},
  {path:'login',component:LoginComponent},
  {path:'register',component:RegisterComponent},
  {path:'',redirectTo:'homepage',pathMatch:'full'},
  {path:'**',redirectTo:'homepage',pathMatch:'full'},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
