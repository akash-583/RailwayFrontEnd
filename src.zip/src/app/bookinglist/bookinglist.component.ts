import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BookingService } from '../Services/booking.service';

@Component({
  selector: 'app-bookinglist',
  templateUrl: './bookinglist.component.html',
  styleUrls: ['./bookinglist.component.css']
})
export class BookinglistComponent implements OnInit {

  isRole: string | null = null;

  dataSource: any[] = [];

  data: any;

  constructor(
    private bookingService: BookingService,
    private router: Router
    ){}

  ngOnInit(): void {
    this.getBookingList();
    this.isRole = sessionStorage.getItem('role');
    this.getBookingList();
  }

  getBookingList() {
    if(this.isRole === 'Admin'){
    this.bookingService.getAllBookings().subscribe({
      next: (res) => {
        this.dataSource = res;
        // console.log("***************************************************")
        console.log(res)
      },
      error: console.error,
    });
  }
  else if(this.isRole === 'User'){
    this.bookingService.viewByUserName().subscribe({
      next: (res) => {
        this.dataSource = res;
        // console.log("***************************************************")
        console.log(res)
      },
      error: console.error,
    });
  }
  }
printPage()
{
  window.print();
}
  cancelTicket(pnr: any) {
    console.log('Deleting train with trainNo: ', pnr);
    this.bookingService.cancelTicket(pnr).subscribe({
      next: (res) => {
        console.log(res);
      },
    });
    alert('Ticket deleted successfully ' + pnr);
    this.getBookingList();
  } 

  details(pnr: any){
    this.bookingService.getDetails(pnr).subscribe({
      next: (res) => {
        this.data=res;
        // console.log("***************************************************")
        console.log(res)
      },
      error: console.error,
    });
  }

  payment(Cost: any){
    sessionStorage.setItem('cost',Cost);
    this.router.navigate(['/payment']);
  }

}
