import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService } from '../Services/login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  signinUser: FormGroup;

  constructor(
    private formBuilder: FormBuilder,
    private loginservice: LoginService,
    private router: Router
  ) {
    this.signinUser = this.formBuilder.group({
      username: ['', [Validators.required]],
      password: ['', [Validators.required]],
    });
  }
  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }
  submitForm() {
    if (this.signinUser.valid) {
      // Submit the form data
      this.loginservice.signinUser(this.signinUser.value).subscribe({
        next: (val: any) => {
          alert('Login Successfully');
          sessionStorage.setItem('loggedIn', 'true');
          sessionStorage.setItem('role', val.roles[0]); // Access the roles array
          sessionStorage.setItem('token', val.accessToken);
          sessionStorage.setItem('username',val.username);
          if(sessionStorage.getItem('role') === 'Admin'){
            this.router.navigate(['/adminlogin']);
            }
            else if(sessionStorage.getItem('role') === 'User'){
              this.router.navigate(['/homepage']);
              }
        },
        error: (error) => {
          console.error('Error:', error);
          alert('Login Failed'); // Handle login failure
        },
      });
    } else {
      // Handle validation errors
      alert('Please Enter Valid Data');
      console.log('Form contains validation errors.');
    }
  }

  goBack() {
    this.router.navigate(['/homepage']); // Reload the page
  }

}
