import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
declare var Razorpay: any;
@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {

  cost = sessionStorage.getItem('totalCost');
username = sessionStorage.getItem('username');
email=sessionStorage.getItem('email');
constructor(private router : Router){

}
  ngOnInit(): void {
  }

payNow() {
  const RozarpayOptions = {
    description: 'Sample Razorpay demo',
    currency: 'INR',
    email: this.email,
    amount: (Number(this.cost) || 0) * 100,
    name: this.username,
    key: 'rzp_test_Tnw3WSxg924MCt',
    image: 'https://i.imgur.com/FApqk3D.jpeg',
    prefill: {
      name: this.username,
       email: this.email,
    },
    theme: {
      color: '#06227e'
    },
    modal: {
      ondismiss:  () => {
        console.log('dismissed');
        this.router.navigate(['/cancel']);
      }
    }
    
  }

  const successCallback = (paymentid: any) => {
    console.log('Success Callback:', paymentid);
    alert('Payment is done');
  };
  
  // this.router.navigate(['/bookingList']);

  this.router.navigate(['/thankyou']);
  
  const failureCallback = (e: any) => {
    console.log('Failure Callback:', e);
    alert('Try it again');
  };
  

  Razorpay.open(RozarpayOptions,successCallback, failureCallback)
}
}
