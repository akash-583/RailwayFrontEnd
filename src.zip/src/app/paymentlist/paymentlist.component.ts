import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PaymentService } from '../Services/payment.service';

@Component({
  selector: 'app-paymentlist',
  templateUrl: './paymentlist.component.html',
  styleUrls: ['./paymentlist.component.css']
})
export class PaymentlistComponent implements OnInit {
  isLoggedIn:boolean=false;
  // neww:string;
  isRole: string | null = null;
  dataSource:any[]=[];
  constructor(
    private paymentService: PaymentService,
    private router: Router,
  ) {
    // this.neww="";
  }
  ngOnInit(): void {
    const loggedInValue = sessionStorage.getItem('loggedIn');
    this.isRole = sessionStorage.getItem('role');
    this.isLoggedIn = loggedInValue === 'true';
    this.getAllPayments();
  }

  getAllPayments()
  {
    // if(this.isLoggedIn){
    //   if(this.isRole === 'Admin'){
    
    this.paymentService.getPaymentList().subscribe({
      next:(res)=>{
        this.dataSource=res;
      },
      error:console.error,
    });
//   }
// }
  }
  printPage()
  {
    window.print();
  }
}
