import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-train',
  templateUrl: './search-train.component.html',
  styleUrls: ['./search-train.component.css']
})
export class SearchTrainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
