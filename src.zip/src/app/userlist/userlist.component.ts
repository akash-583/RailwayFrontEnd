import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../Services/user.service';

@Component({
  selector: 'app-userlist',
  templateUrl: './userlist.component.html',
  styleUrls: ['./userlist.component.css']
})
export class UserlistComponent implements OnInit {

  dataSource: any[] = [];
  isRole: string | null = null;

  constructor(
    private userService: UserService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.isRole = sessionStorage.getItem('role');

    this.getUserList();
  }

  getUserList() {
    this.userService.getAllUsers().subscribe({
      next: (res) => {
        this.dataSource = res;
      },
      error: console.error
    });
  }
printPage()
{
  window.print();
}

}
